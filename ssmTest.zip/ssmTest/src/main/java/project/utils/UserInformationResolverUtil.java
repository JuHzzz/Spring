/**
 * Copyright(C),,TongHuashun
 * FileName:UserInformationResolverUtil
 * Author: JuHzzz
 * Date: 2018/8/4 14:09
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    14:09    1.0.0
 */
package project.utils;

import org.apache.shiro.authc.UsernamePasswordToken;
import project.bean.User;

/***
 *
 * @author JuHzzz
 * @create 2018/8/4
 * @since 1.0.0
 */
public class UserInformationResolverUtil {

    //封装用户登录名和密码
    public static UsernamePasswordToken getUsernamePasswordToken(String userName,String userPassword){

        return new UsernamePasswordToken(userName,userPassword);
    }


    //获取用户信息是否为空
    public static Boolean isNull(String userName,String userPassword){

        boolean result = true;
        if (userName==null||userPassword==null||
                "".equals(userName)||"".equals(userPassword)){
            result = false;
        }
        return result;
    }
}
