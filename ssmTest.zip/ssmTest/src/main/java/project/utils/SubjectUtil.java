/**
 * Copyright(C),,TongHuashun
 * FileName:SubjectUtil
 * Author: JuHzzz
 * Date: 2018/8/4 14:02
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    14:02    1.0.0
 */
package project.utils;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;

/***
 *
 * @author JuHzzz
 * @create 2018/8/4
 * @since 1.0.0
 */
public class SubjectUtil {

    //获取Subject
    public static Subject getSubject(){
        return SecurityUtils.getSubject();
    }

    //验证是否已经认证（登录）
    public static Boolean isAuthenticated(Subject subject){
        return subject.isAuthenticated();
    }



}
