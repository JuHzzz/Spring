/**
 * Copyright(C),,TongHuashun
 * FileName:LoginRealmImpl
 * Author: JuHzzz
 * Date: 2018/8/4 14:14
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    14:14    1.0.0
 */
package project.realm;

import org.apache.shiro.authc.*;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.springframework.beans.factory.annotation.Autowired;
import project.bean.User;
import project.service.UserService;

/***
 *
 * @author JuHzzz
 * @create 2018/8/4
 * @since 1.0.0
 */

public class LoginRealmImpl extends AuthenticatingRealm {
    @Autowired
    private UserService userService;
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
      //1.将AuthenticationToken类型的对象转换为UsernamePasswordToken
        UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken) authenticationToken;
        //2.从UsernamePasswordToken中获取用户名和密码
        String userName = usernamePasswordToken.getUsername();
        //3.调用Dao接口的方法，查询username用户的记录
        User user = userService.getUser(userName);
        System.out.println(user);
        //4.如果username不存在，抛出UnknownAccountException异常：表示用户名不存在
        if (user == null){
            throw new UnknownAccountException("用户名不存在！");
        }
        //5.根据用户信息的情况（是否被锁定等），选择是否抛出其他的异常
        if("monster".equals(user.getUserName())){
            throw new LockedAccountException("用户已经被锁定！");
        }
        //6.根据用户的情况，构建AuthenticationInfo对象并返回
//         public SimpleAuthenticationInfo(Object principal, Object credentials, String realmName)
        /*
        * principal:认证的实体信息，可以是username，也可以是数据表对应的用户的实体类对象
        * credentials：从数据表中获取的username对应的密码
        * realmName：当前realmName对象的name，通过调用父类的getName（）方法可以获得
        * */
        Object principal = user;
        Object credentials = user.getUserPassword();
        String realName = super.getName();
        SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(principal,credentials,realName);
        return simpleAuthenticationInfo;
    }
}
