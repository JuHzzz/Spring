/**
 * Copyright(C),2018-08-03,TongHuashun
 * FileName:UserService
 * Author: JuHzzz
 * Date: 2018/8/3 17:19
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    17:19    1.0.0
 */
package project.service;

import org.apache.ibatis.annotations.Param;
import project.bean.User;

/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
public interface UserService {

    Boolean isExists(User user);
    void createNewUser(User user);
    User getUser(@Param("userName") String userName);
}
