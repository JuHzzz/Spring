/**
 * Copyright(C),,TongHuashun
 * FileName:UserServiceImpl
 * Author: JuHzzz
 * Date: 2018/8/3 17:19
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    17:19    1.0.0
 */
package project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import project.bean.User;
import project.dao.UserDao;

/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
@Service(value = "userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    //注册
    public void createNewUser(User user) {
        userDao.insert(user);
    }

    //登录查询
    public Boolean isExists(User user) {

        Boolean exists = true;
        Integer count = userDao.selectUser(user.getUserName(),user.getUserPassword());
        if(count==0){
            exists = false;
        }
        return  exists;
    }

    //集成shiro后的登录信息查询
    public User getUser(String userName) {
        User user = userDao.selectOne(userName);
        return user;
    }
}
