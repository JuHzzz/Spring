/**
 * Copyright(C),2018-08-03,TongHuashun
 * FileName:UserControl
 * Author: JuHzzz
 * Date: 2018/8/3 17:18
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    17:18    1.0.0
 */
package project.control;

import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import project.bean.User;
import project.service.UserService;
import project.utils.SubjectUtil;
import project.utils.UserInformationResolverUtil;

import java.util.Date;

/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
@Controller
public class UserControl {

    @Autowired
    private UserService userService;

    //注册
    @RequestMapping("/checkRegister.form")
    public String checkRegister(User user) {
        String userName = user.getUserName();
        String userPassword = user.getUserPassword();
        String userRePassword = user.getUserRePassword();
        System.out.println(user);
        if (userName == null || "".equals(userName) || userPassword == null || "".equals(userPassword)
                || userRePassword == null || "".equals(userRePassword)) {
            System.out.println("用户名或密码不能为空");
            return "register";
        }
        if (!userRePassword.equals(userPassword)) {
            System.out.println("密码输入不一致");
            return "register";
        }
        userService.createNewUser(user);
        return "login";
    }


    //登录验证
    @RequestMapping("/index.form")
    public String checkLogin(User user) {

        //获取Subject对象
        Subject subject = SubjectUtil.getSubject();
        //获取用户认证状态
        boolean isAuthenticated = subject.isAuthenticated();
        //如果已经认证
        if (isAuthenticated == true) {

        } else {
            //获取请求中存储的用户信息
            String userName = user.getUserName();
            String userPassword = user.getUserPassword();

            if (UserInformationResolverUtil.isNull(userName,userPassword)==false){
                System.out.println("用户名和密码不能为空请重新输入！！！");
                return "error";
            }else{
                //没有进行认证就需要登录
                //①.将用户名和密码封装成UsernamePasswordToken对象
                UsernamePasswordToken usernamePasswordToken =
                        UserInformationResolverUtil.getUsernamePasswordToken(userName, userPassword);
                usernamePasswordToken.setRememberMe(true);

            /*
            ②执行登录操作
             --- 在login()方法中执行了验证用户名是否存在、通过断言assertCredentialsMatcher方法执行了密码的比对
             --- 存在--》登录
             --- 不存在--》错误*/
                try {
                    subject.login(usernamePasswordToken);
                } catch (UnknownAccountException uae) {
                    uae.printStackTrace();
                    System.out.println("用户名不存在-----》");
                    return "error";
                } catch (IncorrectCredentialsException ice) {
                    ice.printStackTrace();
                    System.out.println("密码输入错误！----》");
                    return "error";
                } catch (LockedAccountException lae) {
                    lae.printStackTrace();
                    System.out.println("您的账户已经被锁定----》");
                    return "error";
                }
            }


        }
        //普通写法（未使用Shiro）
//        if (userService.isExists(user) == true){
//            System.out.println("登录成功！");
//            return "index";
//        }else{
//            System.out.println("同户名或密码错误！");
//            return "error";
//        }
        return "index";
    }

}
