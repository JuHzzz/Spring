/**
 * Copyright(C),,TongHuashun
 * FileName:PageJumpControl
 * Author: JuHzzz
 * Date: 2018/8/3 17:53
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    17:53    1.0.0
 */
package project.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
@Controller
public class PageJumpControl {

    //跳转到注册页
    @RequestMapping(value = "/toRegister.form")
    public String jumpToRegister(){
        return "register";
    }

//    //跳转到登录页退出系统
//    @RequestMapping(value = "/quit.form")
//    public String jumpToQuit(){
//        return  "login";
//    }


}
