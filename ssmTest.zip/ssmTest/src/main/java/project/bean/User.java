/**
 * Copyright(C),2018-08-03,TongHuashun
 * FileName:User
 * Author: JuHzzz
 * Date: 2018/8/3 9:56
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    9:56    1.0.0
 */
package project.bean;

/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
public class User {

    private String userName;
    private String userPassword;
    private String userRePassword;

    public String getUserRePassword() {
        return userRePassword;
    }

    public void setUserRePassword(String userRepassword) {
        this.userRePassword = userRepassword;
    }

    public User() {
    }

    public User(String userName, String userPassword) {
        this.userName = userName;
        this.userPassword = userPassword;

    }

    public String getUserName() {
        return userName;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", userRePassword='" + userRePassword + '\'' +
                '}';
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

}