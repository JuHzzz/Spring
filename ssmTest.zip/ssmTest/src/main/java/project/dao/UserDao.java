/**
 * Copyright(C),2018-08-03,TongHuashun
 * FileName:UserDao
 * Author: JuHzzz
 * Date: 2018/8/3 17:18
 * Description:
 * History:
 * <author>      <time>     <version>     <desc>
 * JuHzzz    17:18    1.0.0
 */
package project.dao;

import org.apache.ibatis.annotations.Param;
import project.bean.User;

/***
 *
 * @author JuHzzz
 * @create 2018/8/3
 * @since 1.0.0
 */
public interface UserDao {

    //添加(实现注册)
    void insert(User user);
    //查询(实现登录)
    Integer selectUser(@Param("userName") String userName,@Param("userPassword") String userPassword);
    //查询某一个用户信息
    User selectOne(@Param("userName")String userName);

}
